package sg.edu.nus.workshopday21.ws21;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ws21Application {

	public static void main(String[] args) {
		SpringApplication.run(Ws21Application.class, args);
	}

}
