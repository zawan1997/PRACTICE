package sg.edu.nus.workshopday21.ws21;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ws21ApplicationTests {

	@Test
	void contextLoads() {
	}

}
